﻿using System;
using PM_Simulation.Controller;
using PM_Simulation.Resource;

namespace PM_Simulation.View
{
    class Startgame
    {
        public Startgame()
        {


        }    
    }
}