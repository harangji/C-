﻿using PM_Simulation.Resource;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM_Simulation.Resource
{
    class MakePokemon
    {
        public List<Pokemon> new_pokemon;
        //public Champion cham = ChampionFactory.CreateChampion("Warrior", "탑신병자");


        private Random random = new Random();

        // 챔피언 타입별 스킬 리스트
        private Dictionary<string, List<ISkill>> skillPool = new Dictionary<string, List<ISkill>>()
        {
            { "노말", new List<ISkill> { new BasicAttack(), new IceSpike(), new FireBlast(), new Test1(), new Test(), new Test2(), new Test3() } },
            { "불꽃", new List<ISkill> { new BasicAttack(), new FireBlast(), new FireBlast(), new Test1(), new Test(), new Test2(), new Test3() } },
            { "물", new List<ISkill> { new BasicAttack(), new BasicAttack(), new FireBlast(), new Test1(), new Test(), new Test2(), new Test3() } },
            { "풀", new List<ISkill> { new BasicAttack(), new IceSpike(), new FireBlast(), new Test1(), new Test(), new Test2(), new Test3() } },
            { "바위", new List<ISkill> { new BasicAttack(), new FireBlast(), new IceSpike(), new Test1(), new Test(), new Test2(), new Test3() } },
            { "땅", new List<ISkill> { new BasicAttack(), new IceSpike(), new Test1(), new Test(), new Test2(), new Test3() } }
        };

        public MakePokemon()
        {
            new_pokemon = new List<Pokemon>();
        }

        private Pokemon CreateChampionWithRandomSkill(string special, string name, string type)
        {
            Pokemon champ = PokemonFactory.CreatePokemon(special, name, type);

            if (skillPool.ContainsKey(type))
            {
                int skillCount = 0; // 추가된 스킬의 수
                    List<ISkill> availableSkills = new List<ISkill>(skillPool[type]); // 가능한 스킬 복사
                    // 중복되지 않는 스킬 찾기
                    while (availableSkills.Count > 0)
                    {
                        ISkill randomSkill = availableSkills[random.Next(availableSkills.Count)];

                        if (champ.HasSkill(randomSkill)) // 이미 배운 스킬인지 체크
                        {
                            champ.AddSkill(randomSkill);
                            skillCount++;
                            if (skillCount == 4)
                            {
                                break;
                            }

                        }
                        else
                        {
                            availableSkills.Remove(randomSkill); // 중복되면 제거 후 다시 시도
                        }
                    }
                }
            return champ;
        }

        public List<Pokemon> Day1()
        {
            new_pokemon.Add(CreateChampionWithRandomSkill("공격형", "공격1", "불꽃"));
            new_pokemon.Add(CreateChampionWithRandomSkill("공격형", "공격2", "물"));
            new_pokemon.Add(CreateChampionWithRandomSkill("방어형", "방어1", "풀"));
            new_pokemon.Add(CreateChampionWithRandomSkill("방어형", "방어2", "풀"));
            new_pokemon.Add(CreateChampionWithRandomSkill("밸런스형", "밸런스1", "노말"));
            new_pokemon.Add(CreateChampionWithRandomSkill("밸런스형", "밸런스2", "노말"));
            return new_pokemon;
        }

        public List<Pokemon> Day2()
        {
            new_pokemon.Add(CreateChampionWithRandomSkill("공격형", "공격3", "비행"));
            new_pokemon.Add(CreateChampionWithRandomSkill("특공형", "특공1", "불꽃"));
            new_pokemon.Add(CreateChampionWithRandomSkill("방어형", "방어3", "바위"));
            new_pokemon.Add(CreateChampionWithRandomSkill("특방형", "특방1", "땅"));
            new_pokemon.Add(CreateChampionWithRandomSkill("스피드형", "스피드1", "비행"));
            new_pokemon.Add(CreateChampionWithRandomSkill("스피드형", "스피드2", "물"));
            return new_pokemon;
        }
    }
}