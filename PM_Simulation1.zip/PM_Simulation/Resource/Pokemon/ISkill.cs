﻿using System;

namespace PM_Simulation.Resource
{
    public interface ISkill
    {
        string SkillName { get; }
        string Rank { get; }
        string AttackType { get; }
        string Type { get; }
        int Damage { get; }
        double Accuracy { get; }
        double CriticalRate { get; }
        int PP { get; }
        void Execute(string name);
    }

    public abstract class SkillBase : ISkill
    {
        public abstract string SkillName { get; }
        public abstract string Rank { get; }
        public abstract string AttackType { get; }
        public abstract string Type { get; }
        public abstract int Damage { get; }
        public abstract double Accuracy { get; }
        public abstract double CriticalRate { get; }
        public abstract int PP { get; }

        public void Execute(string name)
        {
            Console.WriteLine($"{name} 이(가) {SkillName} ({Rank} {AttackType} - {Type}) 공격을 사용했습니다!");
            Console.WriteLine($"데미지: {Damage}, 명중률: {Accuracy}%, 크리티컬 확률: {CriticalRate}%");
            Console.WriteLine($"PP: {PP}");
        }
    }

    public class BasicAttack : SkillBase
    {
        public override string SkillName => "몸통박치기";
        public override string Rank => "C";
        public override string AttackType => "물리";
        public override string Type => "노말";
        public override int Damage => 50;
        public override double Accuracy => 95.0;
        public override double CriticalRate => 5.0;
        public override int PP => 30;
    }

    public class FireBlast : SkillBase
    {
        public override string SkillName => "지옥불";
        public override string Rank => "A";
        public override string AttackType => "특수";
        public override string Type => "불꽃";
        public override int Damage => 70;
        public override double Accuracy => 85.0;
        public override double CriticalRate => 5.0;
        public override int PP => 5;
    }

    public class IceSpike : SkillBase
    {
        public override string SkillName => "얼음 창";
        public override string Rank => "A";
        public override string AttackType => "특수";
        public override string Type => "얼음";
        public override int Damage => 50;
        public override double Accuracy => 90.0;
        public override double CriticalRate => 5.0;
        public override int PP => 10;
    }

    public class Test : SkillBase
    {
        public override string SkillName => "테스트";
        public override string Rank => "S";
        public override string AttackType => "특수";
        public override string Type => "풀";
        public override int Damage => 50;
        public override double Accuracy => 100.0;
        public override double CriticalRate => 100.0;
        public override int PP => 10;
    }
    public class Test1 : SkillBase
    {
        public override string SkillName => "테스트1";
        public override string Rank => "S";
        public override string AttackType => "특수";
        public override string Type => "풀";
        public override int Damage => 50;
        public override double Accuracy => 100.0;
        public override double CriticalRate => 100.0;
        public override int PP => 10;
    }
    public class Test2 : SkillBase
    {
        public override string SkillName => "테스트2";
        public override string Rank => "S";
        public override string AttackType => "특수";
        public override string Type => "풀";
        public override int Damage => 50;
        public override double Accuracy => 100.0;
        public override double CriticalRate => 100.0;
        public override int PP => 10;
    }

    public class Test3 : SkillBase
    {
        public override string SkillName => "테스트3";
        public override string Rank => "S";
        public override string AttackType => "특수";
        public override string Type => "풀";
        public override int Damage => 50;
        public override double Accuracy => 100.0;
        public override double CriticalRate => 100.0;
        public override int PP => 10;
    }
}
