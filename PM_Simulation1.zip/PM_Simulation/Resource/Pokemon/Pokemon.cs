﻿using PM_Simulation.Controller;
using PM_Simulation.Resource;
using System;
using System.Collections.Generic;

namespace PM_Simulation.Resource
{
    public abstract class Pokemon
    {
        public string Name { get; set; }
        public int Hp { get; set; }
        public int Atk { get; set; }
        public int SAtk { get; set; }
        public int Def { get; set; }
        public int SDef { get; set; }
        public int Spd { get; set; }
        public string Type { get; set; }
        public string Special { get; set; }

        public List<ISkill> skills = new List<ISkill>();

        public int Wins { get; set; } = 0;  // 승리 횟수
        public int Losses { get; set; } = 0; // 패배 횟수

        public Pokemon()
        {
            this.Name = "Unknown";
            this.Hp = 100;
            this.Atk = 100;
            this.SAtk = 100;
            this.Def = 100;
            this.SDef = 100;
            this.Spd = 100;
            this.Special = "Default";
            this.Type = "노말";
            
            skills.Add(new BasicAttack());
        }

        public Pokemon(string name, int hp, int atk, int satk, int def, int sdef, int spd, string special, string type,  List<ISkill> skills)
        {
            Name = name;
            Hp = hp;
            Atk = atk;
            SAtk = satk;
            Def = def;
            SDef = sdef;
            Spd = spd;
            Special = special;
            Type = type;
            this.skills = new List<ISkill>(skills); // 리스트 복사
        }


        public bool HasSkill(ISkill skill)
        {
            foreach (var s in skills)
            {
                if (s.SkillName == skill.SkillName) // 같은 이름의 스킬이 있는지 확인
                {
                    return false; // 같은 타입의 스킬이 이미 있다면 true 반환
                }
            }
            return true; // 리스트를 다 돌았는데 없으면 false
        }

        // 스킬 사용 (인덱스로 선택)
        public void UseSkill(int index)
        {
            if (index >= 0 && index < skills.Count)
            {
                skills[index].Execute(Name);
            }
            else
            {
                Console.WriteLine("잘못된 스킬 선택!");
            }
        }

        // 스킬 추가
        public void AddSkill(ISkill newSkill)
        {
            if (!skills.Contains(newSkill))
            {
                skills.Add(newSkill);
                //Console.WriteLine($"{Name}이(가) 새로운 스킬을 배웠습니다!");
            }
        }

        // 스킬 추가
        public void AddSkill_Player(ISkill newSkill)
        {
            if (!skills.Contains(newSkill))
            {
                skills.Add(newSkill);
                Console.WriteLine($"{Name}이(가) 새로운 스킬을 배웠습니다!");
            }
        }
        public double GetWinRate() //승률계산
        {
            int totalBattles = Wins + Losses;
            if (totalBattles == 0)
            {
                return 0; // 아직 전투 기록이 없으면 승률 0
            }
            return (double)Wins / totalBattles * 100;
        }

        // 배운 스킬 출력
        public void DisplaySkills(int x, int y)
        {
            DisplayBuffer.Instance().SetCharacter(x, y, " 스킬 목록");
            for (int i = 0; i < skills.Count; i++)
            {
                //Console.WriteLine($"{i + 1}. {skills[i].SkillName}");
                DisplayBuffer.Instance().SetCharacter(x, y+2+i, $"   {i + 1}. {skills[i].SkillName}");
            }
        }

        public void DisplayStats(int x, int y)
        {

            DisplayBuffer.Instance().SetCharacter(x,y, $" 유형: {Special}, 타입: {Type}, HP: {Hp}, 공격: {Atk}, 특수공격: {SAtk}, 방어: {Def}, 특수방어: {SDef}, 스피드: {Spd}, 승률: {GetWinRate()}          ");
            //Console.WriteLine($"HP: {Hp}, 공격: {Atk}, 특수공격: {SAtk}, 방어: {Def}, 특수방어: {SDef}, 스피드: {Spd}, 타입: {Type}");
        }
    }
}
