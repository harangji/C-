﻿using System;
using System.Collections.Generic;
using PM_Simulation.Resource;

namespace PM_Simulation.Resource
{
    public static class PokemonFactory
    {
        /*
        public string Name { get; set; }
        public int Hp { get; set; }
        public int Atk { get; set; }
        public int SAtk { get; set; }
        public int Def { get; set; }
        public int SDef { get; set; }
        public int Spd { get; set; }
        public string Type { get; set; }

        private List<ISkill> skills = new List<ISkill>(); // 여러 개의 스킬을 저장
        Console.WriteLine($"HP: {Hp}, 공격: {Atk}, 특수공격: {SAtk}, 방어: {Def}, 특수방어: {SDef}, 스피드: {Spd}, 타입: {Type}");
        */
        public static Pokemon CreatePokemon(string Special, string name, string type)
        {
            switch (Special)
            {
                case "공격형":
                    return new Attacker(name, type);
                case "특공형":
                    return new SpecialAttacker(name, type);
                case "방어형":
                    return new Defender(name, type);
                case "특방형":
                    return new SpecialDefender(name, type);
                case "밸런스형":
                    return new Balanced(name, type);
                case "스피드형":
                    return new Speedster(name, type);
                default:
                    throw new ArgumentException("해당하는 유형이 없습니다.");
            }

        }
        static Dictionary<string, List<ISkill>> skillPool = new Dictionary<string, List<ISkill>>() //스킬 선택지
        {
            { "노말", new List<ISkill> { new BasicAttack(), new IceSpike() } },
            { "불꽃", new List<ISkill> { new BasicAttack(), new FireBlast() } },
            { "물", new List<ISkill> { new BasicAttack(), new BasicAttack() } },
            { "풀", new List<ISkill> { new BasicAttack(), new IceSpike() } },
            { "바위", new List<ISkill> { new BasicAttack(), new FireBlast(), new IceSpike() } },
            { "땅", new List<ISkill> { new BasicAttack(), new IceSpike() } }
        };

        //스탯총합 500,   Hp 최소200
        // 공격형 (Attacker)
        public class Attacker : Pokemon
        {
            public Attacker(string name, string type)
                : base(name, 200, 110, 50, 60, 40, 40, "공격형", type, new List<ISkill> { })
                            //HP 공격 특공 방어 특방 스피드
            {
            }
        }

        // 특수공격형 (Special Attacker)
        public class SpecialAttacker : Pokemon
        {
            public SpecialAttacker(string name, string type)
                : base(name, 200, 50, 110, 50, 50, 40, "특공형", type, new List<ISkill> { })
                            //HP 공격 특공 방어 특방 스피드
            {
            }
        }

        // 방어형 (Defender)
        public class Defender : Pokemon
        {
            public Defender(string name, string type)
                : base(name, 250, 60, 30, 110, 80, 20, "방어형", type, new List<ISkill> { })
                            //HP 공격 특공 방어 특방 스피드
            {
            }
        }

        // 특수방어형 (Special Defender)
        public class SpecialDefender : Pokemon
        {
            public SpecialDefender(string name, string type)
                : base(name, 250, 30, 50, 80, 110, 20, "특방형", type, new List<ISkill> { })
                            //HP 공격 특공 방어 특방 스피드
            {
            }
        }

        // 밸런스형 (Balanced)
        public class Balanced : Pokemon
        {
            public Balanced(string name, string type)
                : base(name, 220, 70, 70, 70, 70, 50, "밸런스형", type, new List<ISkill> { })
                            //HP 공격 특공 방어 특방 스피드
            {
            }
        }

        // 스피드형 (Speedster)
        public class Speedster : Pokemon
        {
            public Speedster(string name, string type)
                : base(name, 200, 70, 60, 40, 40, 90, "스피드형", type, new List<ISkill> { })
                            //HP 공격 특공 방어 특방 스피드
            {
            }
        }


    }

}
