﻿using PM_Simulation.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM_Simulation.Resource
{
    public class ButtonData
    {
        MakePokemon makePokemon;
        List<Pokemon> pokemons;

        public ButtonData()
        {
            makePokemon = new MakePokemon();
            pokemons = makePokemon.Day1();
        }

        // 기존의 배열을 List<Button>으로 수정
        public List<Button> MainMenuButtons = new List<Button>
        {
            new Button("게임 시작", 70, 25, new ShowChampionListCommand()),
            //new Button("옵션", 60 + 10, 25 + 1, new OutCommand()),
            new Button("종료", 70 + 2, 25 + 1, new OutCommand()),
            new Button("테스트화면2", 70, 25 + 2, new TestCommand())
        };

        public List<Button> MainMenuButtons2 = new List<Button>
        {
            new Button("메인 메뉴", 30, 10, new MainViewCommand()),
            new Button("옵션", 40, 10, new OutCommand()),
            new Button("<<", 8, 2, new BackCommand())
        };

        public List<Button> PokemonPageButtons = new List<Button>
        {
            new Button("<<", 8, 2, new BackCommand())
        };

        public List<Button> OutButtons = new List<Button>
        {
            new Button("네", 70, 20, new ExitGameCommand()),
            new Button("아니오", 80, 20, new BackCommand())
        };

        // 챔피언 버튼을 생성
        public List<Button> PokemonButtons()
        {
            Console.Clear();

            List<Button> buttons = new List<Button>();
            for (int i = 0; i < pokemons.Count; i++)
            {
                int index = i;
                IButton button = new ShowpokemonInfoCommand(pokemons[index]);
                buttons.Add(new Button(pokemons[i].Name, 30, 10 + (i * 2), button));
            }

            return buttons;
        }

        public List<Button> BattleButtons()
        {
            Console.Clear();

            List<Button> buttons = new List<Button>();
            for (int i = 0; i < pokemons.Count; i++)
            {
                int index = i;
                IButton button = new SelectForBattleCommand(pokemons[index]);
                buttons.Add(new Button(pokemons[i].Name, 30, 10 + (i * 2), button));
            }

            return buttons;
        }
    }
}
