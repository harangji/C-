﻿using PM_Simulation.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM_Simulation.Resource
{
    public interface IButton
    {
        void Execute();
    }
    public class TestCommand : IButton
    {
        public void Execute()
        {
            ViewControl.Instance.Testpage();
        }
    }

    public class MainViewCommand : IButton
    {
        public void Execute()
        {
            ViewControl.Instance.MainPage();
        }
    }

    public class ShowChampionListCommand : IButton //챔피언 리스트 출력
    {
        public void Execute()
        {
            ViewControl.Instance.GamePage();
        }
    }
    public class OutCommand : IButton
    {
        public void Execute()
        {
            ViewControl.Instance.Outpage();
        }
    }
    public class ExitGameCommand : IButton
    {
        public void Execute()
        {
            Console.SetCursorPosition(0, 30);
            Console.WriteLine("잘가용");
            Environment.Exit(0);
        }
    }

    public class BackCommand : IButton
    {
        public void Execute()
        {
            ViewControl.Instance.GoBack();
        }
    }
        public class ShowpokemonInfoCommand : IButton
        {
            private Pokemon _champion;
            public ShowpokemonInfoCommand(Pokemon champion) //챔피언 정보 받아옴
            {
                _champion = champion;
            }

            public void Execute()
            {
                ViewControl.Instance.PokemonInfoPage(_champion);
            }
        }

    public class SelectForBattleCommand : IButton
    {
        private static List<Pokemon> selectedPokemons;
        private Pokemon _pokemon;

        public SelectForBattleCommand(Pokemon pokemon)
        {
            _pokemon = pokemon;
        }

        public void Execute()
        {
            if (selectedPokemons == null)
                selectedPokemons = new List<Pokemon>();

            if (!selectedPokemons.Contains(_pokemon))
            {
                selectedPokemons.Add(_pokemon);
                Console.SetCursorPosition(0, 30 + selectedPokemons.Count);
                Console.WriteLine($"{_pokemon.Name} 선택됨!");
            }

            if (selectedPokemons.Count == 2)
            {
                Console.SetCursorPosition(0, 35);
                Console.WriteLine($"전투 시작: {selectedPokemons[0].Name} vs {selectedPokemons[1].Name}");

                // BattleSimulator 실행
                BattleSimulator simulator = new BattleSimulator(selectedPokemons[0], selectedPokemons[1]);
                simulator.StartBattle();

                // 선택된 포켓몬 초기화
                selectedPokemons.Clear();
            }
        }
    

//public class BattleCommand : IButton
//{
//    private Pokemon _pokemon;
//    private static List<Pokemon> selectedPokemons = new List<Pokemon>();

//    public BattleCommand(Pokemon pokemon)
//    {
//        _pokemon = pokemon;
//    }

//public void Execute()
//        {
//            if (selectedPokemons.Count < 2)
//            {
//                selectedPokemons.Add(_pokemon);
//                Console.SetCursorPosition(0, 30);
//                Console.WriteLine($"{_pokemon.Name} 선택됨 ({selectedPokemons.Count}/2)");

//                if (selectedPokemons.Count == 2)
//                {
//                    StartBattle();
//                }
//            }
//            else
//            {
//                Console.SetCursorPosition(0, 32);
//                Console.WriteLine("이미 두 마리를 선택했습니다!");
//            }
//        }

        private void StartBattle()
        {
            Console.SetCursorPosition(0, 34);
            Console.WriteLine("배틀 시작!");

            //BattleSimulator simulator = new BattleSimulator(selectedPokemons[0], selectedPokemons[1]);
            //simulator.Start();
            selectedPokemons.Clear(); // 배틀 후 선택 초기화
        }
    }
}
