﻿using PM_Simulation.Resource;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PM_Simulation.Controller
{
    public class BattleSimulator
    {
        private Pokemon pokemon1;
        private Pokemon pokemon2;
        private Random random = new Random();

        public BattleSimulator(Pokemon p1, Pokemon p2)
        {
            pokemon1 = p1;
            pokemon2 = p2;
        }

        public void StartBattle()
        {
            // 전투시작이펙트 후

            Console.WriteLine($" {pokemon1.Name} VS {pokemon2.Name} 전투 시작! ");

            Pokemon attacker, defender;

            // 속도가 높은 포켓몬이 선공
            if (pokemon1.Spd > pokemon2.Spd)
            {
                attacker = pokemon1;
                defender = pokemon2;
            }
            else if (pokemon1.Spd < pokemon2.Spd)
            {
                attacker = pokemon2;
                defender = pokemon1;
            }
            else
            {
                // 속도가 같으면 랜덤으로 선공 결정
                attacker = (random.Next(2) == 0) ? pokemon1 : pokemon2;
                defender = (attacker == pokemon1) ? pokemon2 : pokemon1;
            }

            while (pokemon1.Hp > 0 && pokemon2.Hp > 0)
            {
                Console.WriteLine($"\n {attacker.Name}의 턴!");

                // 스킬 선택 (가중치 적용)
                ISkill selectedSkill = SelectSkillWithWeight(attacker);
                int damage = selectedSkill.Damage;

                // 공격 실행
                Console.WriteLine($" {attacker.Name}이(가) {selectedSkill.SkillName} 사용! (데미지: {damage})");
                defender.Hp -= damage;

                if (defender.Hp <= 0)
                {
                    Console.WriteLine($" {defender.Name}이(가) 쓰러졌다!");
                    attacker.Wins++;
                    defender.Losses++;
                    Console.WriteLine($" {attacker.Name} 승리! 승률: {attacker.GetWinRate():F2}%");
                    return;
                }

                // 턴 변경
                (attacker, defender) = (defender, attacker);
            }
        }

        private ISkill SelectSkillWithWeight(Pokemon pokemon)
        {
            List<ISkill> skills = pokemon.skills;
            if (skills.Count == 1) return skills[0];

            // 스킬별 데미지 기반으로 가중치 부여
            Dictionary<ISkill, double> weightedSkills = new Dictionary<ISkill, double>();
            double totalWeight = 0;

            foreach (var skill in skills)
            {
                double weight = Math.Pow(skill.Damage, 1.2); // 데미지가 높을수록 확률 증가
                weightedSkills[skill] = weight;
                totalWeight += weight;
            }

            // 랜덤 값 기반으로 스킬 선택
            double randValue = random.NextDouble() * totalWeight;
            double cumulative = 0;

            foreach (var skill in weightedSkills)
            {
                cumulative += skill.Value;
                if (randValue <= cumulative)
                {
                    return skill.Key;
                }
            }

            return skills[0]; // 기본적으로 첫 번째 스킬 반환
        }
    }
}
