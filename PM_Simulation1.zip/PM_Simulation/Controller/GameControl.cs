﻿using PM_Simulation.View;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM_Simulation.Controller
{
    class GameControl
    {
        public GameControl()
        {
            ViewControl.Instance.MainPage();
            //ViewControl.Instance.GamePage();
        }
    }

}
