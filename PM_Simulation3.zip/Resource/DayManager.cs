﻿using PM_Simulation.Controller;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PM_Simulation.Resource
{
    public class DayManager
    {
        public int currentDay = 0;

        // 싱글톤 인스턴스를 저장할 정적 변수
        private static DayManager instance;
        List<Pokemon> OrderBywinlate;
        double Difference;
        // 외부에서 인스턴스를 접근할 수 있도록 하는 프로퍼티
        public static DayManager Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new DayManager();
                }
                return instance;
            }
        }

        private DayManager()
        {

        }

        // 새로운 날로 넘어가는 메서드
        public void NextDay()
        {
            currentDay++;
            ExecuteDayMethod();
        }

        // 현재 날짜에 맞는 메서드를 실행하는 메서드
        private void ExecuteDayMethod()
        {

            switch (currentDay)
            {
                case 1:
                    MakePokemon.Instance.Day1();
                    break;
                case 2:
                    MultiBattleSimulator multiBattle = new MultiBattleSimulator(30);

                    OrderBywinlate = MakePokemon.Instance.pokemonList.OrderByDescending(p => p.GetWinRate()).ToList();

                    Difference = OrderBywinlate[0].GetWinRate() - OrderBywinlate[OrderBywinlate.Count - 1].GetWinRate(); //일등과 꼴등의 승률차 계산

                    getDifference(Difference);

                    MakePokemon.Instance.Day2();
                    ViewControl.Instance.evaluation -= 10;
                    break;
                case 3:
                    multiBattle = new MultiBattleSimulator(30);
                    getDifference(Difference);
                    MakePokemon.Instance.Day3();
                    ViewControl.Instance.evaluation -= 10;
                    break;
                // 추가적인 case 문을 필요에 맞게 작성하세요
                default:
                    multiBattle = new MultiBattleSimulator(30);
                    MakePokemon.Instance.Dayplus();
                    ViewControl.Instance.evaluation -= 10;
                    break;
            }
        }

        private void getDifference(double Difference)
        {
            if (Difference > 80)
            {
                Console.WriteLine("차가 80이상");
                ViewControl.Instance.public_sentiment -= 15;

            }
            else if (Difference > 50)
            {
                Console.WriteLine("차가 50이상");
                ViewControl.Instance.public_sentiment -= 5;

            }
            else if (Difference > 30)
            {
                Console.WriteLine("차가 30이상");
                ViewControl.Instance.public_sentiment += 5;

            }
            else if (Difference > 10)
            {
                Console.WriteLine("차가 10이상");
                ViewControl.Instance.public_sentiment += 10;

            }
            else
            {
                Console.WriteLine("차가 10이하");
                ViewControl.Instance.public_sentiment += 15;
            }
        }

    }
}
