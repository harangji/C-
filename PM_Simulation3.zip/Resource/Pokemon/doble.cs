﻿namespace PM_Simulation.Resource
{
    internal class doble
    {
    }
}