﻿using PM_Simulation;
using PM_Simulation.Controller;
using PM_Simulation.Resource;
using System;
using System.Runtime.InteropServices;

namespace PM_Simulation
{
    class Program
    {
        // Win32 API: 콘솔 창 크기 변경 방지
        private const int MF_BYCOMMAND = 0x00000000;
        private const int SC_MAXIMIZE = 0xF030; // 최대화 버튼 비활성화
        private const int SC_SIZE = 0xF000;     // 창 크기 조정 비활성화

        [DllImport("user32.dll")]
        private static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);

        [DllImport("user32.dll")]
        private static extern bool DeleteMenu(IntPtr hMenu, int uPosition, int uFlags);

        [DllImport("kernel32.dll")]
        private static extern IntPtr GetConsoleWindow();

        // Win32 API: 콘솔 입력 모드 설정
        private const uint ENABLE_QUICK_EDIT_MODE = 0x0040;
        private const uint ENABLE_WINDOW_INPUT = 0x0008;
        private const uint ENABLE_MOUSE_INPUT = 0x0010;

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool GetConsoleMode(IntPtr hConsoleHandle, out uint lpMode);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern bool SetConsoleMode(IntPtr hConsoleHandle, uint dwMode);

        [DllImport("kernel32.dll", SetLastError = true)]
        private static extern IntPtr GetStdHandle(int nStdHandle);

        private const int STD_INPUT_HANDLE = -10;

        static void Main()
        {
            Console.CursorVisible = false;
            Console.Title = "PM_Simulation";
            Console.SetWindowSize(150, 45);
            Console.SetBufferSize(150, 45);  // 버퍼 크기를 창 크기와 동일하게 설정

            // 창 크기 조정 및 최대화 버튼 비활성화
            IntPtr hMenu = GetSystemMenu(GetConsoleWindow(), false);
            if (hMenu != IntPtr.Zero)
            {
                DeleteMenu(hMenu, SC_SIZE, MF_BYCOMMAND);   // 크기 조정 비활성화
                DeleteMenu(hMenu, SC_MAXIMIZE, MF_BYCOMMAND); // 최대화 버튼 비활성화
            }

            // 콘솔 입력 모드 설정
            IntPtr hInput = GetStdHandle(STD_INPUT_HANDLE);
            if (GetConsoleMode(hInput, out uint mode))
            {
                mode &= ~ENABLE_QUICK_EDIT_MODE; // Quick Edit Mode 비활성화
                mode |= ENABLE_WINDOW_INPUT;     // Window Input 활성화
                mode |= ENABLE_MOUSE_INPUT;      // Mouse Input 활성화

                SetConsoleMode(hInput, mode);
            }

            GameControl games = new GameControl();
        }
    }
}
