﻿using PM_Simulation.Resource;
using System;
using System.Collections.Generic;
using System.Linq;

namespace PM_Simulation.Controller
{
    public class BattleSimulator
    {
        private Pokemon pokemon1;
        private Pokemon pokemon2;
        private int originalHp1;
        private int originalHp2;
        private Random random = new Random();

        public BattleSimulator(Pokemon p1, Pokemon p2)
        {
            pokemon1 = p1;
            pokemon2 = p2;
        }

        public void StartBattle()
        {
            originalHp1 = pokemon1.Hp;
            originalHp2 = pokemon2.Hp;
            Console.Clear();
            Console.WriteLine($" {pokemon1.Name} {pokemon1.Types[0]} {pokemon1.Types[1]} VS {pokemon2.Name} {pokemon1.Types[0]} {pokemon1.Types[1]} 전투 시작! ");

            Pokemon attacker, defender;

            // 속도가 높은 포켓몬이 선공
            if (pokemon1.Spd > pokemon2.Spd)
            {
                attacker = pokemon1;
                defender = pokemon2;
            }
            else if (pokemon1.Spd < pokemon2.Spd)
            {
                attacker = pokemon2;
                defender = pokemon1;
            }
            else
            {
                // 속도가 같으면 랜덤으로 선공 결정
                attacker = (random.Next(2) == 0) ? pokemon1 : pokemon2;
                defender = (attacker == pokemon1) ? pokemon2 : pokemon1;
            }

            while (pokemon1.Hp > 0 && pokemon2.Hp > 0)
            {
                Console.WriteLine($"\n {attacker.Name}의 턴!");
                Console.ReadLine();
                // 스킬 선택 (가중치 적용)
                ISkill selectedSkill = SelectSkillWithWeight(attacker, defender);
                int damage = CalculateDamage(attacker, defender, selectedSkill);

                // 공격 실행
                //if (damage > 0) { 
                //    Console.WriteLine($" {attacker.Name}의 {selectedSkill.SkillName}!   ");
                //    Console.WriteLine($" {defender.Name}은 {damage} 데미지를 입었다!    ");
                //}
                //else
                //{
                //    Console.WriteLine($" {attacker.Name}의 {selectedSkill.SkillName}!");
                //    Console.WriteLine($"하지만 {defender.Name}에게는 맞지 않았다.");
                //}

                defender.Hp -= damage;

                if (defender.Hp <= 0)
                {
                    Console.WriteLine($" {defender.Name}이(가) 쓰러졌다!");
                    attacker.Wins++;
                    defender.Losses++;
                    Console.WriteLine($" {attacker.Name} 승리! 승률: {attacker.GetWinRate():F2}%");
                    Console.ReadLine();
                    Console.Clear();
                    DisplayBuffer.Instance().RenderstartY();
                    pokemon1.Hp = originalHp1;
                    pokemon2.Hp = originalHp2;
                    return;
                }

                // 턴 변경
                (attacker, defender) = (defender, attacker);
            }
        }

        private ISkill SelectSkillWithWeight(Pokemon attacker, Pokemon defender)
        {
            List<ISkill> skills = attacker.skills;
            if (skills.Count == 1) return skills[0];

            // 스킬별 데미지 기반으로 가중치 부여
            Dictionary<ISkill, double> weightedSkills = new Dictionary<ISkill, double>();
            double totalWeight = 0;

            //최종데미지

            foreach (var skill in skills)
            {
                double weight = Math.Pow(CalculateforSelect(attacker, defender, skill), 1.2); // 데미지가 높을수록 확률 증가
                weightedSkills[skill] = weight;
                totalWeight += weight;
            }

            // 랜덤 값 기반으로 스킬 선택
            double randValue = random.NextDouble() * totalWeight;
            double cumulative = 0;

            foreach (var skill in weightedSkills)
            {
                cumulative += skill.Value;
                if (randValue <= cumulative)
                {
                    return skill.Key;
                }
            }

            return skills[0]; // 기본적으로 첫 번째 스킬 반환
        }

        public int CalculateDamage(Pokemon attacker, Pokemon defender, ISkill selectedSkill)
        {
            Random random = new Random();
            int hitChance = random.Next(0, 100); // 0~99 사이 난수 생성

            if (hitChance < selectedSkill.Accuracy)
            {
                // 크리티컬 여부 (예: 20% 확률로 크리티컬)
                bool isCritical = random.Next(100) < selectedSkill.CriticalRate;
                int criticalMultiplier = isCritical ? 2 : 1;

                // 공격과 방어 능력치 선택
                int attackStat = selectedSkill.Type == "물리" ? attacker.Atk : attacker.SAtk;
                int defenseStat = selectedSkill.Type == "물리" ? defender.Def : defender.SDef;

                double typeBonus = GetTypeEffectiveness(selectedSkill.Type, defender.Types);

                // 기본 데미지 계산 (백분율 적용)
                int baseDamage = (int)(attackStat * (selectedSkill.Damage / 100.0) * typeBonus);

                // 방어자의 저항 계산
                double defenseMultiplier = 1 - (defenseStat / (100.0 + defenseStat));

                // 최종 데미지 적용
                int finalDamage = (int)(baseDamage * defenseMultiplier * criticalMultiplier);

                // 최소 1 이상의 데미지 보장
                if (finalDamage < 1)
                    finalDamage = 1;

                // 데미지 로그 출력
                Console.WriteLine($" {attacker.Name}의 {selectedSkill.SkillName}!     ");
                if(typeBonus == 2.0 || typeBonus == 4.0)
                {
                    Console.WriteLine(" 효과가 굉장했다!    ");
                }
                else if(typeBonus == 0.5 || typeBonus == 0.25)
                {
                    Console.WriteLine(" 효과가 별로인 듯 하다...    ");
                }else if(typeBonus == 0.0)
                {
                    Console.WriteLine($" {defender.Name}에게는 효과가 없는 것 같다...    ");
                    return 0;
                }
                Console.WriteLine();

                if (isCritical)
                {
                    Console.WriteLine($" test입니다 {defender.Name}은 {finalDamage} 데미지를 입었다!      ");
                    finalDamage *= 2;
                    Console.WriteLine($" 급소에 맞았다! {defender.Name}은 {finalDamage} 데미지를 입었다!      ");
                }
                else
                {
                    Console.WriteLine($" {defender.Name}은 {finalDamage} 데미지를 입었다!      ");
                }
                return finalDamage;
            }
            else
            {
                Console.WriteLine($" {attacker.Name}의 {selectedSkill.SkillName}!");
                Console.WriteLine($" 하지만 {defender.Name} 에게는 맞지 않았다.");
                return 0;
            }
        }

        public int CalculateforSelect(Pokemon attacker, Pokemon defender, ISkill selectedSkill)
        {
            // 공격과 방어 능력치 선택
            int attackStat = selectedSkill.Type == "물리" ? attacker.Atk : attacker.SAtk;
            int defenseStat = selectedSkill.Type == "물리" ? defender.Def : defender.SDef;

            // 기본 데미지 계산 (백분율 적용)
            int baseDamage = (int)(attackStat * (selectedSkill.Damage / 100.0));

            // 방어자의 저항 계산
            double defenseMultiplier = 1 - (defenseStat / (100.0 + defenseStat));

            // 최종 데미지 적용
            int finalDamage = (int)(baseDamage * defenseMultiplier);

            // 최소 1 이상의 데미지 보장
            if (finalDamage < 1)
                finalDamage = 1;

            return finalDamage;
        }
        public static double GetTypeEffectiveness(string attackType, List<string> defenderTypes)
        {
            Dictionary<string, List<string>> typeMultipliers = new Dictionary<string, List<string>>()
            {
                { "불꽃", new List<string> { "벌레", "강철", "풀", "얼음" } },
                { "물", new List<string> { "불꽃", "땅", "바위" } },
                { "전기", new List<string> { "물", "비행" } },
                { "얼음", new List<string> { "풀", "땅", "비행", "드래곤" } },
                { "풀", new List<string> { "물", "땅", "바위" } },
                { "땅", new List<string> { "불꽃", "전기", "독", "바위", "강철" } }
            };

            Dictionary<string, List<string>> typeResistances = new Dictionary<string, List<string>>()
            {
                { "불꽃", new List<string> { "불꽃", "물", "바위", "드래곤" } }, // 0.5배
                { "물", new List<string> { "물", "풀", "드래곤" } },
                { "전기", new List<string> { "전기", "풀", "드래곤" } },
                { "얼음", new List<string> { "불꽃", "물", "강철", "얼음" } },
                { "풀", new List<string> { "불꽃", "풀", "독", "비행", "벌레", "드래곤", "강철" } },
                { "땅", new List<string> { "풀", "벌레" } }
            };

            Dictionary<string, List<string>> typeImmunities = new Dictionary<string, List<string>>()
            {
                { "전기", new List<string> { "땅" } }, // 0배
                { "땅", new List<string> { "비행" } }
            };

            double effectiveness = 1.0;

            foreach (var defenderType in defenderTypes)
            {
                if (typeMultipliers.ContainsKey(attackType) && typeMultipliers[attackType].Contains(defenderType))
                {
                    effectiveness *= 2.0; // 2배 데미지
                }
                else if (typeResistances.ContainsKey(attackType) && typeResistances[attackType].Contains(defenderType))
                {
                    effectiveness *= 0.5; // 0.5배 데미지
                }
                else if (typeImmunities.ContainsKey(attackType) && typeImmunities[attackType].Contains(defenderType))
                {
                    effectiveness *= 0.0; // 무효
                }
            }
            return effectiveness; // 기본 1배 데미지
        }


    }
}
