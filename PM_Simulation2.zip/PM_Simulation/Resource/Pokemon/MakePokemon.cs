﻿using PM_Simulation.Controller;
using PM_Simulation.Resource;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM_Simulation.Resource
{
    class MakePokemon
    {
        private static MakePokemon _instance;
        public static MakePokemon Instance
        {
            get
            {
                if (_instance == null)
                    _instance = new MakePokemon();
                return _instance;
            }
        }

        public List<Pokemon> pokemonList = new List<Pokemon>();

        private Random random = new Random();

        // 챔피언 타입별 스킬 리스트
        private Dictionary<string, List<ISkill>> skillPool = new Dictionary<string, List<ISkill>>()
        {
            { "노말", new List<ISkill> { new BasicAttack(), new Flame_Baptism(), new Firework(), new IceSpike(),  new Accuracy0(), new CriticalRate100()} },
            { "불꽃", new List<ISkill> { new BasicAttack(), new Flame_Baptism(), new Firework(), } },
            { "물", new List<ISkill>   { new BasicAttack(), } },
            { "풀", new List<ISkill>   { new BasicAttack(), new IceSpike(), new Flame_Baptism()} },
            { "바위", new List<ISkill> { new BasicAttack(), new IceSpike(), new IceSpike()} },
            { "땅", new List<ISkill>   { new BasicAttack(), new IceSpike() } }
        };

        private Pokemon CreateChampionWithRandomSkill(string special, string name, List<string> types)
        {
            Pokemon champ = PokemonFactory.CreatePokemon(special, name, types);

            foreach (var type in types)
            {
                if (skillPool.ContainsKey(type))
                {
                    int skillCount = 0; // 추가된 스킬의 수
                    List<ISkill> availableSkills = new List<ISkill>(skillPool[type]); // 가능한 스킬 복사
                    // 중복되지 않는 스킬 찾기
                    while (availableSkills.Count > 0)
                    {
                        ISkill randomSkill = availableSkills[random.Next(availableSkills.Count)];

                        if (champ.HasSkill(randomSkill)) // 이미 배운 스킬인지 체크
                        {
                            champ.AddSkill(randomSkill);
                            skillCount++;
                            if (skillCount == 4)
                            {
                                break;
                            }
                        }
                        else
                        {
                            availableSkills.Remove(randomSkill); // 중복되면 제거 후 다시 시도
                        }
                    }
                }
            }
            return champ;
        }

        public List<Pokemon> Day1()
        {
            pokemonList.Add(CreateChampionWithRandomSkill("공격형", "공격1", new List<string> { "불꽃","" }));
            pokemonList.Add(CreateChampionWithRandomSkill("공격형", "공격2", new List<string> { "물", "" }));
            pokemonList.Add(CreateChampionWithRandomSkill("방어형", "방어형1", new List<string> { "풀", "" }));
            pokemonList.Add(CreateChampionWithRandomSkill("방어형", "방어형2", new List<string> { "물", "" }));
            pokemonList.Add(CreateChampionWithRandomSkill("밸런스형", "밸런스형1", new List<string> { "불꽃", "" }));
            pokemonList.Add(CreateChampionWithRandomSkill("밸런스형", "밸런스형2", new List<string> { "풀", "" }));
            pokemonList.Add(CreateChampionWithRandomSkill("밸런스형", "노말1", new List<string> { "노말", "" }));
            //pokemonList.Add(CreateChampionWithRandomSkill("방어형", "방어1", "풀"));
            //pokemonList.Add(CreateChampionWithRandomSkill("방어형", "방어2", "풀"));
            //pokemonList.Add(CreateChampionWithRandomSkill("밸런스형", "밸런스1", "노말"));
            //pokemonList.Add(CreateChampionWithRandomSkill("밸런스형", "밸런스2", "노말"));
            return pokemonList;
        }

        public List<Pokemon> Day2()
        {
            Console.WriteLine("테스트테스드");
            Console.ReadLine();
            pokemonList.Add(CreateChampionWithRandomSkill("공격형", "공격3", new List<string> { "비행" }));
            pokemonList.Add(CreateChampionWithRandomSkill("특공형", "특공1", new List<string> { "불꽃" }));
            pokemonList.Add(CreateChampionWithRandomSkill("방어형", "방어3", new List<string> { "바위" }));
            pokemonList.Add(CreateChampionWithRandomSkill("특방형", "특방1", new List<string> { "땅" }));
            pokemonList.Add(CreateChampionWithRandomSkill("스피드형", "스피드1", new List<string> { "비행" }));
            pokemonList.Add(CreateChampionWithRandomSkill("스피드형", "스피드2", new List<string> { "물" }));
            return pokemonList;
        }

        public void SelectRandomForBattle()
        {
            Console.WriteLine(pokemonList[0]);
            if (pokemonList.Count < 2)
            {
                Console.WriteLine("포켓몬이 2마리 이상 필요합니다.");
                return;
            }
            Random random = new Random();

            // 랜덤으로 두 마리 선택
            List<Pokemon> selectedPokemons = new List<Pokemon>();
            while (selectedPokemons.Count < 2)
            {
                Pokemon selected = pokemonList[random.Next(pokemonList.Count)];
                if (!selectedPokemons.Contains(selected))
                {
                    selectedPokemons.Add(selected);
                }
            }

            Battlego(selectedPokemons);
        }

        public void Battlego(List<Pokemon> selectedPokemons)
        {
            Console.SetCursorPosition(0, 30);
            Console.WriteLine($"전투 시작: {selectedPokemons[0].Name} vs {selectedPokemons[1].Name}");

            // BattleSimulator 실행
            BattleSimulator simulator = new BattleSimulator(selectedPokemons[0], selectedPokemons[1]);
            simulator.StartBattle();
        }
    }
}
