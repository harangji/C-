﻿using System;

namespace PM_Simulation.Resource
{
    public interface ISkill
    {
        string SkillName { get; }
        string Rank { get; }
        string AttackType { get; }
        string Type { get; }
        int Damage { get; }
        double Accuracy { get; }
        double CriticalRate { get; }
        string AsciiArt { get; }
    }

    public abstract class SkillBase : ISkill
    {
        public abstract string SkillName { get; }
        public abstract string Rank { get; }
        public abstract string AttackType { get; }
        public abstract string Type { get; }
        public abstract int Damage { get; }
        public abstract double Accuracy { get; }
        public abstract double CriticalRate { get; }
        public abstract string AsciiArt { get; }
    }

    public class BasicAttack : SkillBase
    {
        public override string SkillName => "몸통박치기";
        public override string Rank => "C";
        public override string AttackType => "물리";
        public override string Type => "노말";
        public override int Damage => 40;
        public override double Accuracy => 100.0;
        public override double CriticalRate => 5.0;
        public override string AsciiArt => " ";
    }

    public class Flame_Baptism : SkillBase
    {
        public override string SkillName => "불꽃세례";
        public override string Rank => "B";
        public override string AttackType => "특수";
        public override string Type => "불꽃";
        public override int Damage => 40;
        public override double Accuracy => 100.0;
        public override double CriticalRate => 5.0;
        public override string AsciiArt => " ";
    }

    public class Firework : SkillBase
    {
        public override string SkillName => "불꽃채찍";
        public override string Rank => "B";
        public override string AttackType => "물리";
        public override string Type => "불꽃";
        public override int Damage => 40;
        public override double Accuracy => 100.0;
        public override double CriticalRate => 5.0;
        public override string AsciiArt => " ";
    }

    public class IceSpike : SkillBase
    {
        public override string SkillName => "얼음 뭉치";
        public override string Rank => "B";
        public override string AttackType => "물리";
        public override string Type => "얼음";
        public override int Damage => 40;
        public override double Accuracy => 100.0;
        public override double CriticalRate => 5.0;
        public override string AsciiArt => " ";
    }

        public class Freezingbeam : SkillBase
        {
            public override string SkillName => "냉동 빔";
            public override string Rank => "A";
            public override string AttackType => "특수";
            public override string Type => "얼음";
            public override int Damage => 50;
            public override double Accuracy => 90.0;
            public override double CriticalRate => 5.0;
            public override string AsciiArt => " ";
        }

    public class CriticalRate100 : SkillBase
    {
        public override string SkillName => "크리티컬100";
        public override string Rank => "S";
        public override string AttackType => "특수";
        public override string Type => "풀";
        public override int Damage => 50;
        public override double Accuracy => 100.0;
        public override double CriticalRate => 100.0;
        public override string AsciiArt => " ";
    }

    public class Accuracy0 : SkillBase
    {
        public override string SkillName => "명중0";
        public override string Rank => "S";
        public override string AttackType => "특수";
        public override string Type => "풀";
        public override int Damage => 50;
        public override double Accuracy => 0.0;
        public override double CriticalRate => 100.0;
        public override string AsciiArt => " ";
    }
}
