﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM_Simulation.Resource
{
    public class Patch
    {
        public Patch()
        {
        }
        public void PatchPokemon(Pokemon p)
        {
            // 포켓몬 이름 출력
            Console.Clear();
            Console.WriteLine($"[{p.Name}]의 패치를 시작합니다.");

            // 수정할 속성 선택
            Console.WriteLine("어떤 속성을 수정하시겠습니까?");
            Console.WriteLine("1. 공격력(Atk)");
            Console.WriteLine("2. 방어력(Def)");
            Console.WriteLine("3. 속도(Speed)");
            Console.WriteLine("4. 체력(HP)");
            Console.WriteLine("5. 돌아가기");

            string choice = Console.ReadLine();

            switch (choice)
            {
                case "1":
                    // 공격력 수정
                    Console.WriteLine("수정할 공격력을 입력하세요:");
                    if (int.TryParse(Console.ReadLine(), out int atk))
                    {
                        p.Atk = atk;
                        Console.WriteLine($"공격력이 {atk}로 수정되었습니다.");
                    }
                    else
                    {
                        Console.WriteLine("잘못된 입력입니다. 공격력은 숫자여야 합니다.");
                    }
                    break;

                case "2":
                    // 방어력 수정
                    Console.WriteLine("수정할 방어력을 입력하세요:");
                    if (int.TryParse(Console.ReadLine(), out int def))
                    {
                        p.Def = def;
                        Console.WriteLine($"방어력이 {def}로 수정되었습니다.");
                    }
                    else
                    {
                        Console.WriteLine("잘못된 입력입니다. 방어력은 숫자여야 합니다.");
                    }
                    break;

                case "3":
                    // 속도 수정
                    Console.WriteLine("수정할 속도를 입력하세요:");
                    if (int.TryParse(Console.ReadLine(), out int speed))
                    {
                        p.Spd = speed;
                        Console.WriteLine($"속도가 {speed}로 수정되었습니다.");
                    }
                    else
                    {
                        Console.WriteLine("잘못된 입력입니다. 속도는 숫자여야 합니다.");
                    }
                    break;

                case "4":
                    // 체력 수정
                    Console.WriteLine("수정할 체력을 입력하세요:");
                    if (int.TryParse(Console.ReadLine(), out int hp))
                    {
                        p.Hp = hp;
                        Console.WriteLine($"체력이 {hp}로 수정되었습니다.");
                    }
                    else
                    {
                        Console.WriteLine("잘못된 입력입니다. 체력은 숫자여야 합니다.");
                    }
                    break;

                case "5":
                    // 돌아가기
                    Console.WriteLine("돌아갑니다.");
                    break;

                default:
                    Console.WriteLine("잘못된 선택입니다.");
                    break;
            }

            // 수정 후, 다시 포켓몬의 상태 출력
            Console.WriteLine($"[{p.Name}]의 최신 정보:");
            Console.WriteLine($"공격력: {p.Atk}");
            Console.WriteLine($"방어력: {p.Def}");
            Console.WriteLine($"속도: {p.Spd}");
            Console.WriteLine($"체력: {p.Hp}");

            Console.WriteLine("\n패치가 완료되었습니다. 엔터를 눌러 계속 진행하세요.");
            Console.ReadLine();
        }

    }


}
