﻿using PM_Simulation.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM_Simulation.Resource
{
    public class ButtonData
    {
        List<Pokemon> pokemons;
        // 현재 조회 중인 포켓몬 저장
        public Pokemon selectedPokemon;

        private static ButtonData _instance;
        private static readonly object _lock = new object();

        public static ButtonData Instance
        {
            get
            {
                lock (_lock)
                {
                    if (_instance == null)
                        _instance = new ButtonData();
                    return _instance;
                }
            }
        }

        public ButtonData()
        {
            //makePokemon = new MakePokemon();
            selectedPokemon = null;
            MakePokemon.Instance.Day1();
        }

        // 기존의 배열을 List<Button>으로 수정
        public List<Button> MainMenuButtons = new List<Button>
        {
            new Button("게임 시작", 70, 25, new ShowChampionListCommand()),
            new Button("종료", 70 + 2, 25 + 1, new OutCommand()),
            new Button("테스트화면2", 70, 25 + 2, new TestCommand())
        };

        public List<Button> MainMenuButtons2 = new List<Button>
        {
            new Button("메인 메뉴", 30, 10, new MainViewCommand()),
            new Button("옵션", 40, 10, new OutCommand()),
            new Button("<<", 8, 2, new BackCommand())
        };

        public List<Button> PokemonPageButtons()
        {
            List<Button> buttons = new List<Button>();
            buttons.Add(new Button("<<", 8, 2, new BackCommand()));
            buttons.Add(new Button("패치하기", 50, 30, new PatchCommand(selectedPokemon)));
            return buttons;
        }

        public List<Button> OutButtons = new List<Button>
        {
            new Button("네", 70, 20, new ExitGameCommand()),
            new Button("아니오", 80, 20, new BackCommand())
        };


        private List<Button> _pokemonButtons; // 버튼 리스트 캐싱

        public List<Button> PokemonButtons()
        {
            pokemons = MakePokemon.Instance.pokemonList;
            if (_pokemonButtons == null) // 버튼 리스트가 없으면 생성
            {
                Console.Clear();
                _pokemonButtons = new List<Button>();

                for (int i = 0; i < MakePokemon.Instance.pokemonList.Count; i++)
                {
                    IButton button = new ShowpokemonInfoCommand(MakePokemon.Instance.pokemonList[i]);
                    _pokemonButtons.Add(new Button(MakePokemon.Instance.pokemonList[i].Name, 30, 10 + (i * 2), button));
                    Console.WriteLine(MakePokemon.Instance.pokemonList[i].Name+"testtestsddd");
                    Console.ReadLine(); //지금 두번째부터 아예 이거 자체가 안됨. 아마 null때문?
                }
                _pokemonButtons.Add(new Button("모의전투", 50, 30, new BattleButton()));
                _pokemonButtons.Add(new Button("다음날", 60, 30, new NextDayButton()));
            }

            return _pokemonButtons;
        }

        //public List<IButton> PokemonButtons()
        //{
        //    List<IButton> buttons = new List<IButton>();

        //    // pokemonList가 갱신된 상태에서 버튼을 만듬
        //    foreach (var pokemon in MakePokemon.Instance.pokemonList)
        //    {
        //        buttons.Add(new PokemonButtons(pokemon)); // PokemonButton은 포켓몬 정보를 출력하는 버튼 클래스
        //    }
        //    _pokemonButtons.Add(new Button("모의전투", 50, 30, new BattleButton()));
        //    _pokemonButtons.Add(new Button("다음날", 60, 30, new NextDayButton()));
        //    return buttons;
        //}
    }
}
