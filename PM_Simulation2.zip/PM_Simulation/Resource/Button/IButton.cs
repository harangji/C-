﻿using PM_Simulation.Controller;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM_Simulation.Resource
{
    public interface IButton
    {
        void Execute();
    }
    public class TestCommand : IButton
    {
        public void Execute()
        {
            ViewControl.Instance.Testpage();
        }
    }

    public class MainViewCommand : IButton
    {
        public void Execute()
        {
            ViewControl.Instance.MainPage();
        }
    }

    public class ShowChampionListCommand : IButton //챔피언 리스트 출력
    {
        public void Execute()
        {
            ViewControl.Instance.GamePage();
        }
    }
    public class OutCommand : IButton
    {
        public void Execute()
        {
            ViewControl.Instance.Outpage();
        }
    }
    public class ExitGameCommand : IButton
    {
        public void Execute()
        {
            Console.SetCursorPosition(0, 30);
            Console.WriteLine("잘가용");
            Environment.Exit(0);
        }
    }

    public class BackCommand : IButton
    {
        public void Execute()
        {
            ViewControl.Instance.GoBack();
        }
    }
        public class ShowpokemonInfoCommand : IButton
        {
            private Pokemon _pokemon;
            
            public ShowpokemonInfoCommand(Pokemon pokemon) //챔피언 정보 받아옴
            {
                _pokemon = pokemon;
                ButtonData.Instance.selectedPokemon = pokemon;
            }
            
            public void Execute()
            {
                ViewControl.Instance.PokemonInfoPage(_pokemon);
            }
        }

    public class BattleButton : IButton
    {
        public void Execute()
        {
            //DisplayBuffer.Instance().Clear();
            MakePokemon.Instance.SelectRandomForBattle();
        }
    }
    //public class NextDayButton : IButton
    //{
    //    public void Execute()
    //    {
    //        DisplayBuffer.Instance().Clear();
    //        Console.WriteLine("다음날");
    //        MakePokemon.Instance.Day2();
    //        Console.WriteLine(MakePokemon.Instance.pokemonList[10].Name);
    //        ViewControl.Instance.GamePage();
    //    }
    //}
    public class NextDayButton : IButton
    {
        public void Execute()
        {
            DisplayBuffer.Instance().Clear();
            Console.WriteLine("다음날");
            MakePokemon.Instance.Day2(); // Day2 실행하여 포켓몬 추가

            // Day2 후 pokemonList 상태 확인
            Console.WriteLine(MakePokemon.Instance.pokemonList[10].Name); // 10번째 포켓몬 출력

            // 버튼 갱신을 위해 다시 GamePage 호출
            ViewControl.Instance.GamePage(); // GamePage는 최신 포켓몬 리스트를 반영하도록 함
        }
    }
    public class PatchCommand : IButton
    {
        Pokemon _pokemon;
        Patch patch = new Patch();

        public PatchCommand(Pokemon pokemon) //챔피언 정보 받아옴
        {
            _pokemon = pokemon;
        }

        public void Execute()
        {
            patch.PatchPokemon(_pokemon);
        }
    }
}



