﻿namespace PM_Simulation
{
    internal class HANDLE
    {
    }
}