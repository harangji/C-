﻿using System;
using System.Collections.Generic;
using System.Linq;
using PM_Simulation.Resource;

namespace PM_Simulation.Controller
{
    public class MultiBattleSimulator
    {
        private Random random = new Random();
        private List<Pokemon> pokemonList;
        private int totalBattles;

        public MultiBattleSimulator(int _battleCount)
        {
            pokemonList = new List<Pokemon>(MakePokemon.Instance.pokemonList);
            totalBattles = _battleCount;

            SimulateAllBattles();
        }

        private void SimulateAllBattles()
        {
            // 1. 모든 포켓몬이 최소 한 번은 싸울 수 있도록 짝짓기
            List<Pokemon> shuffledList = pokemonList.OrderBy(p => random.Next()).ToList();
            int totalPokemon = shuffledList.Count;

            for (int i = 0; i < totalPokemon - 1; i += 2)
            {
                SimulateMatch(shuffledList[i], shuffledList[i + 1]);
            }

            // 홀수 개일 경우 마지막 남은 포켓몬 추가 배틀
            if (totalPokemon % 2 == 1)
            {
                SimulateMatch(shuffledList.Last(), shuffledList[random.Next(totalPokemon - 1)]);
            }

            // 2. 남은 배틀 횟수만큼 랜덤 매칭 추가
            int minBattles = totalPokemon / 2 + (totalPokemon % 2);
            int extraBattles = totalBattles - minBattles;

            for (int i = 0; i < extraBattles; i++)
            {
                Pokemon p1 = pokemonList[random.Next(pokemonList.Count)];
                Pokemon p2;
                do
                {
                    p2 = pokemonList[random.Next(pokemonList.Count)];
                } while (p1 == p2);

                SimulateMatch(p1, p2);
            }
        }

        private void SimulateMatch(Pokemon p1, Pokemon p2)
        {
            int wins1 = 0, wins2 = 0;

            for (int i = 0; i < 2; i++) // 2판 진행
            {
                if (SimulateBattle(p1, p2))
                    wins1++;
                else
                    wins2++;
            }

        }

        private bool SimulateBattle(Pokemon pokemon1, Pokemon pokemon2)
        {
            int originalHp1 = pokemon1.Hp;
            int originalHp2 = pokemon2.Hp;

            Pokemon attacker, defender;
            if (pokemon1.Spd > pokemon2.Spd)
            {
                attacker = pokemon1;
                defender = pokemon2;
            }
            else if (pokemon1.Spd < pokemon2.Spd)
            {
                attacker = pokemon2;
                defender = pokemon1;
            }
            else
            {
                attacker = (random.Next(2) == 0) ? pokemon1 : pokemon2;
                defender = (attacker == pokemon1) ? pokemon2 : pokemon1;
            }

            while (pokemon1.Hp > 0 && pokemon2.Hp > 0)
            {
                ISkill selectedSkill = SelectSkillWithWeight(attacker, defender);
                int damage = CalculateDamage(attacker, defender, selectedSkill);
                defender.Hp -= damage;

                if (defender.Hp <= 0)
                {
                    attacker.Wins++;
                    defender.Losses++;
                    ResetBattle(pokemon1, pokemon2, originalHp1, originalHp2);
                    return attacker == pokemon1;
                }

                (attacker, defender) = (defender, attacker);
            }
            return false;
        }

        private ISkill SelectSkillWithWeight(Pokemon attacker, Pokemon defender)
        {
            List<ISkill> skills = attacker.skills;
            if (skills.Count == 1) return skills[0];

            Dictionary<ISkill, double> weightedSkills = new Dictionary<ISkill, double>();
            double totalWeight = 0;

            foreach (var skill in skills)
            {
                double weight = Math.Pow(CalculateForSelect(attacker, defender, skill), 1.2);
                weightedSkills[skill] = weight;
                totalWeight += weight;
            }

            double randValue = random.NextDouble() * totalWeight;
            double cumulative = 0;

            foreach (var skill in weightedSkills)
            {
                cumulative += skill.Value;
                if (randValue <= cumulative)
                    return skill.Key;
            }

            return skills[0];
        }

        private int CalculateDamage(Pokemon attacker, Pokemon defender, ISkill selectedSkill)
        {
            if (random.Next(100) < selectedSkill.Accuracy)
            {
                bool isCritical = random.Next(100) < selectedSkill.CriticalRate;
                int criticalMultiplier = isCritical ? 2 : 1;
                int attackStat = selectedSkill.Type == "물리" ? attacker.Atk : attacker.SAtk;
                int defenseStat = selectedSkill.Type == "물리" ? defender.Def : defender.SDef;
                double typeBonus = BattleSimulator.GetTypeBonus(selectedSkill.Type, defender.Types);

                int baseDamage = (int)(attackStat * (selectedSkill.Damage / 100.0) * typeBonus);
                double defenseMultiplier = 1 - (defenseStat / (150.0 + defenseStat));
                int finalDamage = (int)(baseDamage * defenseMultiplier * criticalMultiplier);

                return Math.Max(finalDamage, 1);
            }
            return 0;
        }

        private int CalculateForSelect(Pokemon attacker, Pokemon defender, ISkill selectedSkill)
        {
            int attackStat = selectedSkill.Type == "물리" ? attacker.Atk : attacker.SAtk;
            int defenseStat = selectedSkill.Type == "물리" ? defender.Def : defender.SDef;
            int baseDamage = (int)(attackStat * (selectedSkill.Damage / 100.0));
            double defenseMultiplier = 1 - (defenseStat / (100.0 + defenseStat));
            return Math.Max((int)(baseDamage * defenseMultiplier), 1);
        }

        private void ResetBattle(Pokemon pokemon1, Pokemon pokemon2, int originalHp1, int originalHp2)
        {
            pokemon1.Hp = originalHp1;
            pokemon2.Hp = originalHp2;
        }
    }
}
