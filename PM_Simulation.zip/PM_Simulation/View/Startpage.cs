﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM_Simulation
{
    
    class Startpage
    {
        static string[] buttons = { "시작", "설정", "종료" };
        static int selectedIndex = 0; // 현재 선택된 버튼 인덱스

        public Startpage()
        {
            playerkey();
            DrawButtons();
        }

        public void playerkey()
        {
            while (true)
            {
                Console.SetCursorPosition(0, 0);
                DrawButtons();

                // 키 입력 처리
                ConsoleKeyInfo key = Console.ReadKey();

                if (key.Key == ConsoleKey.UpArrow)
                    selectedIndex = (selectedIndex - 1 + buttons.Length) % buttons.Length;
                else if (key.Key == ConsoleKey.DownArrow)
                    selectedIndex = (selectedIndex + 1) % buttons.Length;
                else if (key.Key == ConsoleKey.Enter)
                {
                    Console.Clear();
                    Console.WriteLine($"[{buttons[selectedIndex]}] 버튼이 선택됨!");
                    break;
                }
            }
        }
        public void DrawButtons()
        {
            for(int j =0; j<10; j++)
            {
                Console.WriteLine();
            }

            for (int i = 0; i < buttons.Length; i++)
            {
                if (i == selectedIndex)
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine($"                                    ▶ {buttons[i]} ◀");
                    Console.ResetColor();
                }
                else
                {
                    Console.WriteLine($"                                      {buttons[i]}            ");
                }
            }
        }
    }
}
