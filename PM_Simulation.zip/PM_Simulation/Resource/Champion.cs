﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PM_Simulation
{
    public enum Status
    {   
        Name,
        //Hp,   ?실제 전투를 구현할까?
        Skill,
        Type,
        ChampScore
    }
    public interface qwe
    {
    }

    class Champion
    {
        
    }
}
