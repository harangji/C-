﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20250123_homework_2
{
    class Ai : Player
    {
        public List<Card> visibleCards { get; set; }
        public new string Name = "AI";
        private Genealogy genealogy = new Genealogy();

        // 플레이어의 카드 출력: isVisible 여부에 따라 출력 방식 결정
        public new void ShowCards()
        {
            Console.WriteLine("AI의 카드:");

            foreach (var card in Hands)
            {
                if (card.isVisible)
                {
                    card.Viewing_card(); // 보이는 카드는 일반 출력
                }
                else
                {
                    // 숨겨진 카드 ?로 출력
                    Console.Write("|? ?|");
                }
            }
            Console.Write($"                보유 {Money} 원");
            Console.WriteLine();
        }

        // 플레이어의 카드 출력: isVisible 여부에 따라 출력 방식 결정
        public new void ShowLastCards()
        {
            Console.WriteLine("AI의 카드:");

            foreach (var card in Hands)
            {
                card.isVisible = true;
                card.Viewing_card();

            }
            Console.Write($"                보유 {Money} 원");
            Console.WriteLine();
        }


        //public new void Half(int bet)
        //{
        //    int halfBet = bet * 2;
        //    if (Money - (halfBet) <= 0) // 남은 돈이 설정한 판돈보다 적을 때
        //    {
        //        Console.WriteLine($"{Name}는 올인을 했습니다.");
        //        SevenPoker.pot += Money;
        //        Money = 0;
        //    }
        //    else
        //    {
        //        Console.WriteLine($"{Name}는 {halfBet}원으로 레이즈 했습니다.");
        //        SevenPoker.pot += halfBet;
        //        Money -= halfBet;
        //    }

        //}

        public void AiChoice(List<Card> p_cards, int LastBetMoney)
        {

            if (genealogy.EvaluateHand(p_cards).Item2 >= 80) //플레이어 오픈패 강함
            {
                //Console.WriteLine($"테스트{genealogy.EvaluateHand(p_cards).Item2}");
                die(); //다이
            }
            else if (genealogy.EvaluateHand(p_cards).Item2 >= 50)//  ~~~~~~~~~
            {
                //Console.WriteLine($"테스트{genealogy.EvaluateHand(p_cards).Item2}");
                Call(LastBetMoney); //콜
            }

            else if (genealogy.EvaluateHand(p_cards).Item2 < 50) //플레이어 오픈패 약함
            {
                //Console.WriteLine($"테스트{genealogy.EvaluateHand(p_cards).Item2}");
                Call(LastBetMoney); //하프 또는 콜
            }

        }

        public new void Call(int LastBetMoney)
        {
            Console.WriteLine($"{Name}는 콜을 했습니다.");
            Console.WriteLine($"{Name}는 {LastBetMoney}원을 베팅했습니다.");
            Money -= LastBetMoney;
            SevenPoker.pot += LastBetMoney;
            SevenPoker.gameContinues = false; //베팅 종료
            SevenPoker.betRound = 0; // 레이즈 최대횟수 판별자 초기화
            Console.ReadLine();
        }

        public new void die() //AI 다이
        {
            Console.WriteLine($"{Name}는 다이를 했습니다.");
            Player.Money += SevenPoker.pot;
            SevenPoker.pot = 0;
            SevenPoker.gameContinues = false;
            Console.WriteLine("모인 판돈을 플레이어가 얻습니다.");
            Console.WriteLine("게임을 다시 시작합니다.");
            Console.ReadLine();

            SevenPoker game = new SevenPoker();
            game.Gamestart();

        }
    }
}