﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace _20250123_homework_2
{
    public class Genealogy
    {

        public (string, int) EvaluateHand(List<Card> hand)
        {
            if (isRoyalStraightFlush(hand)) return ("로얄 플러쉬", 100);
            if (isBackFlush(hand)) return ("백 플러쉬", 95);
            if (isStraight_Flush(hand)) return ("스트레이트 플러쉬", 90);
            if (isPoker(hand)) return ("포카드", 80);
            if (isFullHouse(hand)) return ("풀하우스", 70);
            if (isFlush(hand)) return ("플러쉬", 60);
            if (isMountin(hand)) return ("마운틴", 50);
            if (isBackStraight(hand)) return ("백 스트레이트", 40);
            if (isStraight(hand)) return ("스트레이트", 30);
            if (isTriple(hand)) return ("트리플", 20);
            if (isTwoPair(hand)) return ("투페어", 10);
            if (isPair(hand)) return ("원페어", 5);
            return ("하이 카드", 0);
        }

        public List<Card> sort_Card(List<Card> card)
        {

            //선택정렬
            //정렬되지 않은 데이터들을 가장 작은 데이터를 찾아
            //가장 앞의 데이터와 교환하는 방식
            for (int i = 0; i < card.Count; i++)
            {
                for (int j = i + 1; j < card.Count; j++)
                {
                    //부등호 방향 > (오름차순),  < (내림차순)
                    if (card[i].num > card[j].num)
                    {
                        Card temp = card[i];
                        card[i] = card[j];
                        card[j] = temp;
                    }
                }
            }

            //or
            //card.Sort(); //퀵정렬 기반

            return card;
        }

        //카드의 자료구조를 넣었을 때 모든 카드 패턴 검사
        public bool isSameSimbol(List<Card> card)
        {
            /*
             * 패턴이 전카드와 맞는지 아닌지만
             */
            for (int i = 1; i < card.Count; i++)
            {
                if (!card[i - 1].pattern.Equals(card[i].pattern))
                {
                    //패턴이 맞지 않음
                    return false;
                }
            }
            return true;
        }

        public bool isSearchCard_index(int index, List<Card> card)
        {
            /*
             반복문으로 처음부터 끝까지 돌고
            해당 index를 만나면 break;
             */
            for (int i = 0; i < card.Count; i++)
            {
                if (card[i].num.Equals(index))
                {
                    return true;
                }
            }
            return false;

        }
        public Card isSearchCard_C(int index, List<Card> card)
        {
            for (int i = 0; i < card.Count; i++)
            {
                if (card[i].num.Equals(index))
                {
                    return card[i];
                }
            }
            return new Card(0, 0);
        }

        //특정 index를 기준으로 연속되는 숫자가 나오는 것
        // 2 3 4 5 6
        public bool isCountinuityNum(List<Card> card, out List<Card> madecard)
        {
            int card_startindex = 0;
            int stright_count = 0;
            madecard = new List<Card>();

            //5 숫자가 연속이 될 때 -> 비교할 카드가 5장 이상 남아있을때
            //card -> 결과 도출하는 메서드에서 꼭 정렬하고 할겁니다.
            while (card_startindex <= (card.Count - 5))
            {
                //6 8 10 j q k
                if (card_startindex > card.Count - 5)
                {
                    if (madecard.Count > 0)
                    {
                        madecard.Clear();
                    }
                    return false; //-> 메소드 자체를 나가버림
                }

                int current_num = card[card_startindex].num;
                int past_num = 0;
                for (int i = card_startindex; i < card.Count; i++)
                {
                    if (i.Equals(card_startindex))
                    {
                        //그냥 시작할겁니다...
                        past_num = current_num + 1;
                        stright_count += 1;
                        madecard.Add(card[i]);
                    }

                    //
                    else if (!card[i].num.Equals(past_num) || past_num > 10)
                    {
                        card_startindex += 1;
                        stright_count = 0;
                        past_num = 0;
                        if (madecard.Count > 0)
                        {
                            madecard.Clear();
                        }
                        break;
                    }
                    else
                    {
                        stright_count += 1;
                        past_num += 1;
                        madecard.Add(card[i]);
                    }
                }// for 끝
                if (stright_count.Equals(5))
                {
                    return true;
                }
            } //while 끝

            if (madecard.Count > 0)
            {
                madecard.Clear();
            }
            return false;
        }


        //1. 로얄 스트레이트 플러쉬
        //10 J Q K A를 같은 무늬로 모은 경우
        public bool isRoyalStraightFlush(List<Card> cards)
        {
            if (cards.Count < 5) return false;
            List<Card> MadeCard = new List<Card>();
            MadeCard.Add(isSearchCard_C(10, cards));
            MadeCard.Add(isSearchCard_C(11, cards));
            MadeCard.Add(isSearchCard_C(12, cards));
            MadeCard.Add(isSearchCard_C(13, cards));
            MadeCard.Add(isSearchCard_C(1, cards));
            for (int i = 0; i < MadeCard.Count; i++)
            {
                if (MadeCard[i].num.Equals(0))
                {
                    return false;
                }
            }
            if (isSameSimbol(MadeCard))
            {
                return true;
            }
            return false;

        }

        // 2. 백스트레이트 플러쉬
        // A 2 3 4 5 를 같은 무늬로 모은 경우
        public bool isBackFlush(List<Card> cards)
        {
            if (cards.Count < 5) return false;
            List<Card> MadeCard = new List<Card>();
            MadeCard.Add(isSearchCard_C(1, cards));
            MadeCard.Add(isSearchCard_C(2, cards));
            MadeCard.Add(isSearchCard_C(3, cards));
            MadeCard.Add(isSearchCard_C(4, cards));
            MadeCard.Add(isSearchCard_C(5, cards));

            for (int i = 0; i < MadeCard.Count; i++)
            {
                if (MadeCard[i].num.Equals(0))
                {
                    return false;
                }
            }
            if (isSameSimbol(MadeCard))
            {
                return true;
            }
            return false;

        }

        //3. 스트레이트 플러쉬
        // 연속되는 숫자 5개를 같은 무늬로 모은 경우
        public bool isStraight_Flush(List<Card> cards)
        {
            if (cards.Count < 5) return false;
            cards = sort_Card(cards);

            if (cards[0].num > 10) return false; //가장 작은 값이 10"보다" 크면 스트레이트 성립불가
            else
            {
                if (isCountinuityNum(cards, out List<Card> madecard))
                {
                    //연속되는 숫자는 생겼습니다.
                    if (!isSameSimbol(madecard))
                    {
                        return false;
                    }
                    else
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        //Poker
        //무늬는 다르지만 같은 숫자 4개를 모은 경우
        public bool isPoker(List<Card> card)
        {
            if (card.Count < 4) return false;
            card = sort_Card(card);
            int count = 0;
            for (int i = 0; i < card.Count; i++)
            {
                for (int j = 1; j < card.Count; j++)
                {
                    if (i != j && card[i].num.Equals(card[j].num))
                    {
                        count += 1;
                    }
                }
            }

            if (count.Equals(12))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //5. 풀하우스
        //무늬가 다른 같은숫자 3개 2개를 각각 모은 경우
        private bool isFullHouse(List<Card> card)
        {
            if (card.Count < 5) return false;
            card = sort_Card(card);
            int count = 0;
            for (int i = 0; i < card.Count; i++)
            {
                for (int j = 1; j < card.Count; j++)
                {
                    if (i != j && card[i].num.Equals(card[j].num))
                    {
                        count += 1;
                    }
                }
            }

            if (count.Equals(8))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        //6. 플러쉬
        //숫자 관계 없이 같은 무늬 카드 5개를 모은 경우
        public bool isFlush(List<Card> card)
        {
            if (card.Count < 5) return false;
            card = sort_Card(card);
            int count = 0;

            for (int i = 0; i < card.Count; i++)
            {
                for (int j = 1; j < card.Count; j++)
                {
                    if (i != j && card[i].pattern.Equals(card[j].pattern))
                    {
                        count += 1;
                    }
                }
            }

            if (count >= 20)
            {
                return true;
            }

            return false;

        }

        //7. 마운틴
        // 무늬 관계 없이 A 2 3 4 5 를 모은경우
        public bool isMountin(List<Card> card)
        {
            if (card.Count < 5) return false;

            card = sort_Card(card);

            if (isSearchCard_index(1, card) &&
                isSearchCard_index(2, card) &&
                isSearchCard_index(3, card) &&
                isSearchCard_index(4, card) &&
                isSearchCard_index(5, card))
            {
                return true;
            }

            return false;

        }

        //8. 백스트레이트
        // 무늬 관계없이 10 j q k a를 모은경우
        public bool isBackStraight(List<Card> card)
        {
            if (card.Count < 5) return false;

            card = sort_Card(card);

            if (isSearchCard_index(1, card) &&
                isSearchCard_index(10, card) &&
                isSearchCard_index(11, card) &&
                isSearchCard_index(12, card) &&
                isSearchCard_index(13, card))
            {
                return true;
            }

            return false;

        }

        //9. 스트레이트
        //무늬 관계없이 연속되는 숫자 5개를 모은경우
        public bool isStraight(List<Card> card)
        {
            if (card.Count < 5) return false;
            return isCountinuityNum(card, out List<Card> a); //out 매개변수 사용안함

        }

        //10. 트리플
        //무늬 관계 없이 같은숫자 3개
        public bool isTriple(List<Card> card)
        {
            if (card.Count < 3) return false;
            card = sort_Card(card);
            int count = 0;
            int[] arr_int = new int[3];

            for (int i = 0; i < card.Count; i++)
            {
                for (int j = 1; j < card.Count; j++)
                {
                    if (i != j && card[i].num.Equals(card[j].num))
                    {
                        count += 1;
                        if (count % 2 == 0)
                        {
                            arr_int[(count / 2) - 1] = card[i].num;
                        }
                    }
                }
            }

            if (count.Equals(6))
            {
                if (arr_int[0].Equals(arr_int[1]) &&
                    arr_int[0].Equals(arr_int[2]) &&
                    arr_int[2].Equals(arr_int[1]))
                    return true;
                else
                    return false;
            }

            return false;
        }


        //11.투페어
        //같은 숫자 두개(원페어 *2) 두쌍 있는 패
        public bool isTwoPair(List<Card> card)
        {
            if (card.Count < 4) return false;
            card = sort_Card(card);
            int count = 0;
            int past_num = 0;

            for (int i = 0; i < card.Count; i++)
            {
                for (int j = 1; j < card.Count; j++)
                {
                    if (i != j && card[i].num.Equals(card[j].num))
                    {
                        count += 1;
                        if (count.Equals(2))
                        {
                            past_num = card[i].num;
                            break;
                        }
                    }
                }
            }
            if (count >= 2)
            {
                count = 0;
            }
            else return false;

            //-------------------------------------------------

            for (int i = 0; i < card.Count; i++)
            {
                for (int j = 1; j < card.Count; j++)
                {
                    if (i != j && card[i].num.Equals(card[j].num) &&
                        !past_num.Equals(card[i].num))
                    {
                        count += 1;
                        if (count.Equals(2))
                        {
                            break;
                        }
                    }
                }
            }
            if (count.Equals(2) && past_num != 0)
            {
                return true; //투페어
            }
            else return false;
        }

        //12. 원페어
        //무늬 관계없이 같은숫자 2장 모은경우
        private bool isPair(List<Card> card)
        {
            if (card.Count < 2) return false;
            card = sort_Card(card);
            int count = 0;

            for (int i = 0; i < card.Count; i++)
            {
                for (int j = 1; j < card.Count; j++)
                {
                    if (i != j && card[i].num.Equals(card[j].num))
                    {
                        count += 1;
                        if (count.Equals(2))
                        {
                            return true;
                        }
                    }
                }
            }
            return false;

        }
    }
}
