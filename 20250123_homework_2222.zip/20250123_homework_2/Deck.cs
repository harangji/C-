﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20250123_homework_2
{
    public enum Pattern
    {
        Spades,
        Diamonds,
        Hearts,
        Clover
    }

    /// <summary>
    /// 카드는 class 
    /// Array로 카드를 만들고
    /// 플레이어가 카드를 가지고 가면 List
    /// </summary>

    public class Card
    {
        /*
         A
        2 3 4 5 6 7 8 9 10 j q k
         */
        public int num;
        public Pattern pattern;
        public bool isVisible;

        public Card(int _num, Pattern p, bool visible = false)
        {
            num = _num;
            pattern = p;
            isVisible = visible;  // 기본값 false 숨겨진 상태
        }

        public void Viewing_card()
        {
            //"♠""♣""♥""◆"
            string Pattern_s = string.Empty;
            switch (pattern)
            {
                case Pattern.Spades:
                    Pattern_s = "♠";
                    break;
                case Pattern.Diamonds:
                    Pattern_s = "◆";
                    break;
                case Pattern.Hearts:
                    Pattern_s = "♥";
                    break;
                case Pattern.Clover:
                    Pattern_s = "♣";
                    break;
            }


            /*
             1 2 3 4 5 6 7 8 9 10 11 12 13
             A                    J   Q  K
             */

            string number_s = string.Empty;
            if (num.Equals(1) || num.Equals(11) ||
                num.Equals(12) || num.Equals(13))
            {
                //문자 변경 1 11 12 13 
                switch (num)
                {
                    case 1:
                        number_s = "A";
                        break;
                    case 11:
                        number_s = "J";
                        break;
                    case 12:
                        number_s = "Q";
                        break;
                    case 13:
                        number_s = "K";
                        break;
                }
            }
            else
            {
                number_s = num.ToString();
            }

            Console.Write($"|{Pattern_s} {number_s}|");
        }
    }

    public class Deck
    {
        private List<Card> cards_list;

        //카드 생성
        public void make_cards()
        {

            cards_list = new List<Card>();

            for (int i = 0; i < 4; i++)
            {
                for (int k = 0; k < 13; k++)
                {
                    cards_list.Add(new Card(k + 1, (Pattern)i));
                }
            }
            Console.WriteLine("카드 생성이 완료되었습니다.");
            Console.ReadLine();

            //테스트용 카드 출력
            //for (int i = 0; i < cards_list.Count; i++)
            //{
            //    if (i % 13 == 0)
            //    {
            //        Console.WriteLine();
            //    }
            //    cards_list[i].Viewing_card();
            //}

            
            //셔플
            cards_list = Suffle_Card(cards_list, 1000);

            List<Card> Suffle_Card(List<Card> cards, int sufflecount)
            {
                List<Card> return_card = new List<Card>();
                return_card = cards;
                Card temp_card = new Card(0, 0);
                Random rnd = new Random();
                int cardcount = return_card.Count;
                for (int i = 0; i < sufflecount; i++)
                {
                    int F_index = rnd.Next(0, cardcount);
                    int S_index = rnd.Next(0, cardcount);
                    if (F_index.Equals(S_index))
                    {
                        S_index = rnd.Next(0, cardcount);
                    }
                    temp_card = return_card[F_index];
                    return_card[F_index] = return_card[S_index];
                    return_card[S_index] = temp_card;
                }
                return return_card;
            }
           
        }

        //카드 뽑기
        public List<Card> Draw(int noc, bool isVisible) //Number of cards 뽑을 카드 수
        {
            List<Card> Player_Card = new List<Card>();

            Console.Clear();
            try
            {
                for (int n = 0; n < noc; n++)
                {
                    //Console.ReadLine();
                    //Console.Clear();

                    Card drawnCard = CardPick(ref cards_list);
                    drawnCard.isVisible = isVisible;
                    Player_Card.Add(drawnCard);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"뽑을 수 있는 모든 카드를 뽑았습니다.(오류처리): {ex.Message}");
            }

            return Player_Card;

            Card CardPick(ref List<Card> cards)
            {
                Card temp = cards[0];
                cards.RemoveAt(0);
                return temp;
            }
        }

    }
}