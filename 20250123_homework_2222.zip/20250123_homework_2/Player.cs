﻿using System;
using System.Collections.Generic;

namespace _20250123_homework_2
{
    public class Player
    {
        public List<Card> Hands { get; private set; }
        public static int Money { get; set; }
        public string Name = "플레이어";
        private int currentBet = 1000;      // 기본 베팅금액
        private int betMoney = 0;           // 추가 베팅금액
        private int total_betMoney = 0;         // 총 베팅금액

        private Genealogy genealogy = new Genealogy();

        public Player()
        {
            Hands = new List<Card>();
            Money = 1000000;
        }

        // 카드를 받아 리스트에 추가
        public void ReceiveCards(List<Card> cards)
        {
            Hands.AddRange(cards);
        }

        // 플레이어의 카드 출력: isVisible 여부에 따라 출력 방식 결정
        public void ShowCards()
        {
            Console.WriteLine("플레이어의 카드:");

            foreach (var card in Hands)
            {
                if (card.isVisible)
                {
                    card.Viewing_card(); // 보이는 카드는 일반 출력
                }
                else
                {
                    // 숨겨진 카드는 회색 출력
                    Console.ForegroundColor = ConsoleColor.DarkGray;
                    card.Viewing_card();
                    Console.ResetColor();
                }
            }
            Console.Write($"                보유 {Money} 원");
            Console.WriteLine();
        }

        // 플레이어의 카드 출력: isVisible 여부에 따라 출력 방식 결정
        public void ShowLastCards()
        {
            Console.WriteLine("플레이어의 카드:");

            foreach (var card in Hands)
            {
                card.isVisible = true;
                card.Viewing_card();
            }
            Console.Write($"                보유 {Money} 원");
            Console.WriteLine();
        }




        public int Call()
        {

                Console.WriteLine("기본 판돈은 1000원입니다. 판돈을 더 올리려면 추가해주세요.   ex) 1000 ");
                string input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("입력이 없으므로 판돈을 추가하지 않습니다.");
                }
                else
                {
                    try
                    {
                        betMoney = int.Parse(input);
                        if (betMoney < 0)
                        {
                            Console.WriteLine("음수는 입력할 수 없습니다. 판돈을 추가하지 않습니다.");
                            betMoney = 0;
                        }
                    }
                    catch (FormatException)
                    {
                        Console.WriteLine("숫자만 입력할 수 있습니다. 판돈을 추가하지 않습니다.");
                    }

                }
           
                total_betMoney = currentBet + betMoney;

            if ((Money - total_betMoney) <= 0) //남은 돈이 설정한 판돈보다 적을 때
            {
                Console.WriteLine($"{Name}는 올인을 했습니다.");
                total_betMoney = Money;
                Money = 0;
                return total_betMoney; //총 베팅금액 = 남은 돈 전부 => 판돈으로 더함


                //AiChoice = AiBet(1, Money, genealogy.EvaluateHand(ai.Hands).Item2); //ai 선택 ( 콜, 상대 판돈, 패 점수 ) Item2 = EvaluateHand=> score

            }
            else
            {
                Money -= total_betMoney;
                SevenPoker.pot += total_betMoney;

                Console.WriteLine($"콜! {Name}는 {total_betMoney}원을 베팅했습니다.");
                Console.ReadLine();
                return total_betMoney;
            }
        }

        public void Half(int bet)
        {
            int halfBet = bet * 2;
            if (Money - (halfBet) <= 0) // 남은 돈이 설정한 판돈보다 적을 때
            {
                Console.WriteLine($"{Name}는 올인을 했습니다.");
                SevenPoker.pot += Money;
                Money = 0;
            }
            else
            {
                Console.WriteLine($"{Name}는 {halfBet}원으로 레이즈 했습니다.");
                SevenPoker.pot += halfBet;
                Money -= halfBet;
            }


        }

        public void die() //플레이어 다이
        {
            Console.WriteLine($"플레이어는 다이를 했습니다.");
            Ai.Money += SevenPoker.pot;
            SevenPoker.pot = 0;
            Console.ReadLine();
        }
    }
}
