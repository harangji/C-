﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20250123_homework_2
{
    public class SevenPoker
    {
        private Deck deck = new Deck();
        private Player player = new Player();
        private Ai ai = new Ai();
        private Genealogy genealogy = new Genealogy();

        private int open;               // 오픈카드 선택 변수
        private int discard;            // 버릴카드 선택 변수

        public static int LastBetMoney = 0;     //콜을 불렀을때 상대 판돈 기준
        public static bool gameContinues =true;       //베팅 루프 탈출용 변수
        public static int betRound = 0;         //최대 레이즈 횟수 판별 변수
        public static int turn = 0;


        private int playerBetMoney =0;
        public static int pot = 0;          // 판돈 합계
        private int AiChoice = 0;           // AI 선택지 저장


        //private Genealogy = new Genealogy();

        public void Rule()
        {
            //1. 4장의 히든카드를 받고 1장을 버리기
            //2. 남은 3장중 1장을 오픈하기
            //3. 오픈한 1장의 카드를 기준으로 선 정하기
            //4. 선을 기준으로 남은카드에서 한장 오픈하기
            //5. 베팅
            //6. 모두 콜이 되면 오픈카드를 드로우 후 베팅
            //7. 6을 두번더 반복
            //8. 히든카드를 받고 베팅 (받은 사람 본인은 볼 수 있음)
            //9. 족보평가
        }

        public void Gamestart()
        {

            //----------------------------------------------------------------------
            //1. 4장의 히든카드를 받고 1장을 버리기

            //카드 생성
            deck.make_cards();

            //카드 뽑기
            //List<Card> drawnCardsP = deck.Draw(4);
            //List<Card> drawnCardsA = deck.Draw(4);
            //Console.Clear();
            DrawAllPlayers(4); //현재 카드 4장

            ShowAllCards();

            Console.WriteLine("버릴 카드 선택하기 ex)1 ");

            DiscardAllPlayers(); //현재 카드 3장

            ShowAllCards();


            //----------------------------------------------------------------------
            //2. 남은 3장중 1장을 오픈하기

            Console.WriteLine("오픈할 카드 선택하기");
            OpenAllPlayers();

            Console.Clear();
            ShowAllCards();

            //----------------------------------------------------------------------
            //3. 오픈한 1장의 카드를 기준으로 선 정하기
            //4. 선을 기준으로 남은카드에서 한장 오픈하기

            Console.WriteLine("오픈할 카드 선택하기");
            OpenAllPlayers();

            Console.Clear();
            ShowAllCards();

            //----------------------------------------------------------------------
            //5. 베팅
            //6. 모두 콜이 되면 오픈카드를 드로우 후 베팅

            StartBettingRound();

            Console.WriteLine("오픈카드를 드로우합니다.");
            Console.ReadLine();

            DrawAllPlayers(1,true); //현재 카드 4장
            ShowAllCards();

            StartBettingRound();

            //----------------------------------------------------------------------
            //7. 6을 두번더 반복

            DrawAllPlayers(1, true); //현재 카드 5장
            ShowAllCards();

            StartBettingRound();

            DrawAllPlayers(1, true); //현재 카드 6장
            ShowAllCards();

            StartBettingRound();

            //----------------------------------------------------------------------
            //8. 히든카드를 받고 베팅 (받은 사람 본인은 볼 수 있음)
            DrawAllPlayers(1, false); //현재 카드 7장
            StartBettingRound();

            //----------------------------------------------------------------------
            //9. 족보평가
            //마지막 턴 카드조합 공개. isVisible = true

            ShowLastCards();

            //족보
            Console.WriteLine($"플레이어의 카드패는 {genealogy.EvaluateHand(player.Hands).Item1}");
            Console.WriteLine($"AI의 카드패는 {genealogy.EvaluateHand(ai.Hands).Item1}");
        }

        public void ShowAllCards()
        {
            Console.Clear();
            Console.WriteLine("===============================\n");
            player.ShowCards();
            Console.WriteLine("\n===============================\n");
            ai.ShowCards();
            Console.WriteLine("\n===============================\n");
        }

        public void ShowLastCards()
        {
            Console.Clear();
            Console.WriteLine("===============================\n");
            player.ShowLastCards();
            Console.WriteLine("\n===============================\n");
            ai.ShowLastCards();
            Console.WriteLine("\n===============================\n");
        }

        public void DrawAllPlayers(int i, bool isVisible = false)
        {
            player.ReceiveCards(deck.Draw(i, isVisible));
            ai.ReceiveCards(deck.Draw(i, isVisible));
        }

        public void OpenAllPlayers()
        {
            while (true)
            {
                try
                {
                    open = int.Parse(Console.ReadLine());

                    // open이 1보다 작은 값이거나 Hands 배열의 크기를 넘는 인덱스일 경우 예외 처리
                    if (open < 1 || open > player.Hands.Count)
                    {
                        Console.WriteLine("잘못된 입력입니다. 유효한 번호를 입력하세요.");
                        continue;
                    }

                    break;
                }
                catch (FormatException)
                {
                    Console.WriteLine("잘못된 형식입니다. 숫자를 입력해주세요.");
                }
            }

            // 카드가 이미 보이도록 설정되었으면 다시 한번 메소드 실행
            if (player.Hands[open - 1].isVisible)
            {
                Console.WriteLine("이 카드는 이미 공개되었습니다. 다시 선택해주세요.");
                OpenAllPlayers(); // 메소드 다시 호출
                return; // 현재 메소드 종료
            }

            //플레이어 - 오픈한 카드를 ai에게 전달해야함
            player.Hands[open -1].isVisible = true;

            //AI
            //(genealogy.EvaluateHand(ai.Hands).Item2)
            ai.Hands[open - 1].isVisible = true; //점수로 판단하게 바꾸기, while문 위로 올리기
        }

        public void DiscardAllPlayers()
        {
            while (true)
            {
                try
                {
                    discard = int.Parse(Console.ReadLine());

            // discard가 1보다 작은 값이거나 Hands 리스트의 크기를 넘는 인덱스일 경우 예외 처리
            if (discard < 1 || discard > player.Hands.Count)
            {
                Console.WriteLine("잘못된 입력입니다. 유효한 번호를 입력하세요.");
                continue;
            }

            break;
             }
                catch (FormatException)
                {
                    Console.WriteLine("잘못된 형식입니다. 숫자를 입력해주세요.");
                }
            }

            player.Hands.RemoveAt(discard - 1);
            ai.Hands.RemoveAt(discard - 1);
        }

        public void StartBettingRound()
        {
            Console.Clear();
            ShowAllCards();

            P_Bet();

            Console.ReadLine(); //대기
            
        }
        // 베팅 시스템
        public void P_Bet()
        {
            gameContinues = true;


            Console.WriteLine("플레이어의 턴");
            Console.WriteLine("콜 | 하프 | 다이 | 체크     또는 1,2,3,4 ");


                string Action = Console.ReadLine()?.Trim(); // 입력값이 null일 경우 방지하고 공백 제거

            if (betRound >= 3)
            {
                gameContinues = false;
                Console.WriteLine("모든 레이즈 횟수를 소진했습니다.");
                Console.WriteLine("턴을 종료합니다.");
                betRound = 0; //초기화
                return;
            }

            while (gameContinues)
            {

                if (Player.Money >= 1000) //패배 트리거
                {
                    switch (Action.ToLower())
                    {
                        case "1":
                        case "콜":
                            playerBetMoney = player.Call();
 
                            LastBetMoney = playerBetMoney;
                            ai.AiChoice(GetVisibleCards(), LastBetMoney);

                            Console.WriteLine($"현재 판돈 {pot} 원");
                            Console.ReadLine();
                            betRound++;
                            break;

                        case "2":
                        case "하프":
                            //Half();


                            betRound++;
                            break;

                        case "3":
                        case "체크":
                            if (turn == 0)
                            {
                                Console.WriteLine("첫번째 턴에는 체크할 수 없습니다.");
                                P_Bet();
                                break;
                            }
                            Console.WriteLine("체크! 베팅을 유지합니다.");
                            
                            break;

                        case "4":
                        case "다이":
                            Console.WriteLine("다이!");
                            Console.WriteLine("쌓인 판돈을 상대가 가져갑니다.");
                            player.die();
                            break;

                        default:
                            Console.WriteLine("잘못된 입력입니다.");
                            P_Bet();
                            break;
                    }
                }
                else
                {
                    //패배 트리거
                    gameContinues = false;
                    Console.WriteLine("돈이 부족합니다!");
                    Console.WriteLine("게임에서 패배했습니다.");
                    Console.ReadLine();
                }
            }
        }


        // isVisible이 true인 카드들만 필터링하여 반환
        public List<Card> GetVisibleCards()
        {
            // LINQ를 사용하여 isVisible이 true인 카드들만 필터링
            return player.Hands.Where(card => card.isVisible).ToList();
        }

    }
}
