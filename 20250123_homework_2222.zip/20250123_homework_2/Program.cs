﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20250123_homework_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("잠시만 기다려주세요.");
            Deck deck = new Deck();
            SevenPoker _7poker = new SevenPoker();
            _7poker.Gamestart();
        }

        }
    }